/* eslint-disable prettier/prettier */
export const jwtConstants = {
  secret: 'abc000&*',
};