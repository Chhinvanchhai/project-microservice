export class CreateProductDto {
  name: string;
  category_id: number;
  sku: string;
  quantity: number;
}
